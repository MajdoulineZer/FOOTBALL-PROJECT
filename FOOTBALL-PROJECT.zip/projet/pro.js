function fonc1(){
    if(getComputedStyle(eqp1).display != "none"){
        eqp1.style.display = "none";
    } else {
        eqp1.style.display = "block";
    }
  };
 
  function fonc2(){
    if(getComputedStyle(eqp2).display != "none"){
        eqp2.style.display = "none";
    } else {
        eqp2.style.display = "block";
    }
  };
  
  function fonc3(){
    if(getComputedStyle(eqp3).display != "none"){
        eqp3.style.display = "none";
    } else {
        eqp3.style.display = "block";
    }
  };
   
  function fonc4(){
    if(getComputedStyle(eqp4).display != "none"){
        eqp4.style.display = "none";
    } else {
        eqp4.style.display = "block";
    }
  };
   
  function fonc5(){
    if(getComputedStyle(eqp5).display != "none"){
        eqp5.style.display = "none";
    } else {
        eqp5.style.display = "block";
    }
  };
   
  function fonc6(){
    if(getComputedStyle(eqp6).display != "none"){
        eqp6.style.display = "none";
    } else {
        eqp6.style.display = "block";
    }
  };
   
  function fonc7(){
    if(getComputedStyle(eqp7).display != "none"){
        eqp7.style.display = "none";
    } else {
        eqp7.style.display = "block";
    }
  };
   
  function fonc8(){
    if(getComputedStyle(eqp8).display != "none"){
        eqp8.style.display = "none";
    } else {
        eqp8.style.display = "block";
    }
  };

//hafiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa

  function fiche1(){
    if(getComputedStyle(fichea).display != "none"){
        fichea.style.display = "none";
    } else {
        fichea.style.display = "block";
    }
  };
 

  function fiche2(){
    if(getComputedStyle(ficheb).display != "none"){
        ficheb.style.display = "none";
    } else {
        ficheb.style.display = "block";
    }
  };

  function fiche3(){
    if(getComputedStyle(fichec).display != "none"){
        fichec.style.display = "none";
    } else {
        fichec.style.display = "block";
    }
  };

  function fiche4(){
    if(getComputedStyle(fiched).display != "none"){
        fiched.style.display = "none";
    } else {
        fiched.style.display = "block";
    }
  };

  function fiche5(){
    if(getComputedStyle(fichee).display != "none"){
        fichee.style.display = "none";
    } else {
        fichee.style.display = "block";
    }
  };

  function fiche6(){
    if(getComputedStyle(fichef).display != "none"){
        fichef.style.display = "none";
    } else {
        fichef.style.display = "block";
    }
  };

  function fiche7(){
    if(getComputedStyle(ficheg).display != "none"){
        ficheg.style.display = "none";
    } else {
        ficheg.style.display = "block";
    }
  };

  function fiche8(){
    if(getComputedStyle(ficheh).display != "none"){
        ficheh.style.display = "none";
    } else {
        ficheh.style.display = "block";
    }
  };

  