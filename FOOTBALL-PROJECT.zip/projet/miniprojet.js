 src="https://kit.fontawesome.com/9044f3b38c.js" crossorigin="anonymous"

 